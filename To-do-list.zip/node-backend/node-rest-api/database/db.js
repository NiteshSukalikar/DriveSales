module.exports = {
   // db: 'mongodb://localhost:27017/test'
    db : 'mongodb+srv://tiger:tiger@cluster0.bczuj.mongodb.net/?retryWrites=true&w=majority'
};